// Descripcion: este programa lee el nombre de un archivo, valida que exista, cuenta cuantas lineas en blanco, comentadas y las restantes. Además imprime los resultados en pantalla.
// Autora: Patricia Palula Aguilar      Matricula: A01732537
// Fecha de la ultima modificacion: 26 de agosto de 2021

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

int main()
{
    cout << "Hello World" << endl;
    return 0;
}

class LeerArchivo
{
private:
    string nombreArchivo;
    int linBlancas = 0, linComent = 0, linCodigo = 0, linTotal = 0;

public:
    // Constructores
    LeerArchivo()
    {
        nombreArchivo = "";
    }

    LeerArchivo(string nameFile, int white, int comm, int code, int tot)
    {
        nombreArchivo = "";
        linBlancas = white;
        linComent = comm;
        linCodigo = code;
        linTotal = tot;
    }

    // Metodos GET
    string getNombreArchivo()
    {
        return nombreArchivo;
    }

    int getLinBlancas()
    {
        return linBlancas;
    }

    int getLinComent()
    {
        return linComent;
    }

    int getLinCodigo()
    {
        return linCodigo;
    }

    int getLinTotal()
    {
        return linTotal;
    }

    // Metodos SET
    void setNombreArchivo(string name)
    {
        nombreArchivo = name;
    }

    void setLinBlancas(int white)
    {
        linBlancas = white;
    }

    void setLinComent(int comm)
    {
        linComent = comm;
    }

    void setLinCodigo(int code)
    {
        linCodigo = code;
    }

    void setLinTotal(int tot)
    {
        linTotal = tot;
    }

    // Metodos

    // funcion: lee de la pantalla el nombre del archivo y lo asigna a la variable correspondiente.
    void leerNombre()
    {
        cout << "Escriba el nombre del archivo: ";
        cin >> nombreArchivo;
    }

    // funcion: abre el archivo, verifica si existe y si esta vacio. Cuenta las lineas en blanco, comentarios las demás lineas, calcula el total y asigna los valores a las variables.
    void contarLineas()
    {
        ifstream archivo;
        archivo.open(nombreArchivo);
        if (archivo)
        {
            string line;
            while (!archivo.eof())
            {
                getline(archivo, line);
                int i = 0;
                while (i < line.length())
                {
                    if (line[0] == ' ')
                    {
                        line.erase(0, 1);
                    }
                    else
                    {

                        if (line[0] == '/')
                        {
                            if (line[1] == '/')
                            {
                                linComent++;
                                // salirrrrr
                            }
                            else if (line[1] == '*')
                            {
                                linComent++;
                                getline(archivo, line);
                                line.erase(0, 2);
                                while (line.find("*/") == -1)
                                {
                                    getline(archivo, line);
                                    linComent++;
                                }
                                // salirrrrr
                            }
                            linCodigo++;
                        }
                        else
                        {
                            linCodigo++;
                        }
                    }
                    i++;
                }
            }
        }
    }
};