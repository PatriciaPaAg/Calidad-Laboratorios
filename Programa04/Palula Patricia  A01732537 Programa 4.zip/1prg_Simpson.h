#include <iostream>
#include <string>
#include "FunctionT.h"

using namespace std;

class Simpson
{
private:
    double x, dof, w;
    int n;
    double pI, pF;
    double errMax = 0.0001;

public:
    //.i
    Simpson(double equis, double grados)
    {
        x = equis;
        dof = grados;
        n = 10;
        obtenerPf();
    }

    //.i
    double calcularP()
    {
        double sum = 0;
        w = x / n;
        //cout << "x = " << x << endl;
        //cout << "n = " << n << endl;
        //cout << "w = " << w << endl;
        FunctionT fun(dof);
        fun.setX(0);
        sum += fun.getResul();
        //cout << "f(0) = " << fun.getResul() << endl;
        for (int i = 1; i < n; i++)
        {
            if (i % 2 == 1)
            {
                fun.setX(i * w);
                sum += 4 * fun.getResul();
                //cout << "f(" << i << "*" << w << ") = " << fun.getResul() << endl;
            }
            else
            {
                fun.setX(i * w);
                sum += 2 * fun.getResul();
                //cout << "f(" << i << "*" << w << ") = " << fun.getResul() << endl;
            }
        }
        fun.setX(x);
        sum += fun.getResul();
        //cout << "f(x) = " << fun.getResul() << endl;
        return w / 3 * sum;
    };

    //.i
    void obtenerPf()
    {
        pI = calcularP();
        n *= 2;
        pF = calcularP();
        while (pF - pI > errMax)
        {
            pI = pF;
            n *= 2;
            pF = calcularP();
        }
    };

    //.i
    void imprimirResul()
    {
        cout << "  x = " << x << endl;
        cout << "dof = " << dof << endl;
        cout << "  p = " << pF << endl;
    };
};